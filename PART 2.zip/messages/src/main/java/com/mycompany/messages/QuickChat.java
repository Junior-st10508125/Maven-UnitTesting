/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.messages;

import java.util.Scanner;
import java.util.ArrayList;

public class QuickChat {

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            ArrayList<Messages> messages = new ArrayList<>();
            
            System.out.println("Welcome to QuickChat.");
            
            // Simple login check
            System.out.print("Enter username: ");
            String username = input.nextLine();
            
            System.out.print("Enter password: ");
            String password = input.nextLine();
            
            if (username.isEmpty() || password.isEmpty()) {
                System.out.println("Login failed.");
                input.close();
                return;
            }
            
            System.out.println("Login successful.");
            
            int choice = 0;
            int messageNumber = 0;
            
            while (choice != 3) {
                
                System.out.println("\nQuickChat Menu");
                System.out.println("1. Send Messages");
                System.out.println("2. Show recently sent messages");
                System.out.println("3. Quit");
                System.out.print("Choose an option: ");
                
                choice = Integer.parseInt(input.nextLine());
                
                switch (choice) {
                    
                    case 1 -> {
                        System.out.print(
                                "How many messages do you want to send? ");
                        int numberOfMessages =
                                Integer.parseInt(input.nextLine());
                        
                        for (int i = 0; i < numberOfMessages; i++) {
                            
                            System.out.print("Enter recipient number: ");
                            String recipient = input.nextLine();
                            
                            Messages temporaryMessage =
                                    new Messages(messageNumber,
                                            recipient, "Temporary");
                            
                            while (!temporaryMessage.checkRecipientCell()
                                    .equals("Cell phone number successfully captured.")) {
                                
                                System.out.println(
                                        temporaryMessage.checkRecipientCell());
                                
                                System.out.print(
                                        "Enter recipient number again: ");
                                recipient = input.nextLine();
                                
                                temporaryMessage = new Messages(
                                        messageNumber, recipient, "Temporary");
                            }
                            
                            System.out.print("Enter your message: ");
                            String text = input.nextLine();
                            
                            while (text.length() > 250 || text.isEmpty()) {
                                System.out.println(
                                        "Please enter a message of less than "
                                                + "250 characters.");
                                
                                System.out.print("Enter your message: ");
                                text = input.nextLine();
                            }
                            
                            Messages newMessage = new Messages(
                                    messageNumber, recipient, text);
                            
                            System.out.println(
                                    newMessage.printMessages());
                            
                            System.out.println(
                                    newMessage.SentMessage());
                            
                            messages.add(newMessage);
                            messageNumber++;
                        }
                        
                        System.out.println("Messages completed.");
                    }
                    
                    case 2 -> System.out.println("Coming Soon.");
                    
                    case 3 -> System.out.println("Goodbye.");
                    
                    default -> System.out.println(
                            "Invalid option. Please choose 1, 2 or 3.");
                }
            }
            
            if (!messages.isEmpty()) {
                System.out.println(
                        "Total messages sent: "
                                + messages.get(0).returnTotalMessages());
            } else {
                System.out.println("Total messages sent: 0");
            }
        }
    }
}