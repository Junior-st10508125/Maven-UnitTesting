package com.mycompany.messages;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessagesTest {
    Messages msg1 = new Messages(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
    Messages msg2 = new Messages(1, "08575975889", "Hi Keegan, did you receive the payment?");

    @Test
    public void testMessageLength_Success() {
        assertEquals("Message ready to send.", msg1.checkMessageLength());
    }
    @Test
    public void testMessageLength_Failure() {
        String longMsg = "A".repeat(260);
        Messages longmessage = new Messages(0, "+27718693002", longMsg);
        assertTrue(longmessage.checkMessageLength().contains("Message exceeds 250 characters by"));
    }
    @Test
    public void testValidRecipientNumber() {
        assertEquals("Cell phone number successfully captured.", msg1.checkRecipientCell());
    }
    @Test
    public void testInvalidRecipientNumber() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg2.checkRecipientCell());
    }
    @Test
    public void testMessageHash() {
        assertEquals("00:0:HITONIGHT", msg1.createMessageHash());
    }
}