/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messages;

import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public final class Messages {
    
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private final String messageHash;

    private static int totalMessagesSent = 0;

    public Messages(int messagesNumber, String recipient, String messages) {

    this.messageID = generateMessageID();
    this.messageNumber = messagesNumber;
    this.recipient = recipient;
    this.message = messages;

    this.messageHash = createMessageHash();

    totalMessagesSent++;
}
    

    // Generate a 10-digit message ID
    private String generateMessageID() {
        Random random = new Random();
        String id = "";

        for (int i = 0; i < 10; i++) {
            id = id + random.nextInt(10);
        }

        return id;
    }

    // Check the message ID
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Check the recipient cell number
    public String checkRecipientCell() {
        if (recipient.length() <= 10
                && recipient.startsWith("+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted "
                    + "or does not contain an international code.";
        }
    }

    // Create the message hash
    public String createMessageHash() {
        String[] words = message.trim().split("\\s+ ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        String firstTwoDigits = messageID.substring(0, 2);

        return (firstTwoDigits + ":"
                + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // Allow the user to send, disregard or store a message
    public String SentMessage() {
        Scanner input = new Scanner(System.in);

        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        System.out.print("Choose an option: ");

        int choice = input.nextInt();

        switch (choice) {
            case 1 -> {
                totalMessagesSent++;
                return "Message successfully sent.";
            }
            case 2 -> {
                return "Press 0 to delete the message.";
            }
            case 3 -> {
                storeMessage();
                return "Message successfully stored.";
            }
            default -> {
                return "Invalid option.";
            }
        }
    }

    // Return all messages sent during the program
    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // Return total messages sent
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Store message in a JSON file
    public void storeMessage() {
        try {
            try (FileWriter writer = new FileWriter("messages.json", true)) {
                writer.write("{\n");
                writer.write("\"messageID\": \"" + messageID + "\",\n");
                writer.write("\"messageHash\": \"" + messageHash + "\",\n");
                writer.write("\"recipient\": \"" + recipient + "\",\n");
                writer.write("\"message\": \"" + message + "\"\n");
                writer.write("}\n");
            }

        } catch (IOException e) {
            System.out.println("Error storing message.");
        }
    }
}