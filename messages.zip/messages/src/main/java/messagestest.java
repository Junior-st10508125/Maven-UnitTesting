/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class messagestest {

    @Test
    public void testSendMessage() {

        // Test Data for Message 1
        String recipient = "+27718693002";
        String message = "Hi Mike, can you join us for dinner tonight?";
        String action = "Send";

        // Verify test data
        assertEquals("+27718693002", recipient);
        assertEquals(
            "Hi Mike, can you join us for dinner tonight?",
            message
        );
        assertEquals("Send", action);

        // Expected result
        int totalMessagesSent = 1;
        assertEquals(1, totalMessagesSent);
    }

    @Test
    public void testDiscardMessage() {

        // Test Data for Message 2
        String recipient = "08575975889";
        String message = "Hi Keegan, did you receive the payment?";
        String action = "Discard";

        // Verify test data
        assertEquals("08575975889", recipient);
        assertEquals(
            "Hi Keegan, did you receive the payment?",
            message
        );
        assertEquals("Discard", action);

        // A discarded message must not increase the sent count
        int totalMessagesSent = 1;
        assertEquals(1, totalMessagesSent);
    }
}
    

