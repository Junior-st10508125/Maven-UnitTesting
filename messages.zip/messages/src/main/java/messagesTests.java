/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class messagesTests {

    // Test 1: Message must not exceed 250 characters
    @Test
    public void testMessageLength() {
        String message = "Hi Mike, can you join us for dinner tonight?";

        if (message.length() <= 250) {
            assertEquals("Message ready to send.",
                    "Message ready to send.");
        } else {
            int excess = message.length() - 250;
            assertEquals(
                "Message exceeds 250 characters by " + excess
                + "; please reduce the size.",
                "Message exceeds 250 characters by " + excess
                + "; please reduce the size."
            );
        }
    }

    // Test 2: Message exceeding 250 characters
    @Test
    public void testMessageTooLong() {
        String message = "A".repeat(251);
        int excess = message.length() - 250;

        assertTrue(message.length() > 250);
        assertEquals(1, excess);
    }

    // Test 3: Correctly formatted recipient number
    @Test
    public void testValidRecipientNumber() {
        String recipient = "+27718693002";

        assertTrue(recipient.matches("^\\+[1-9]\\d{1,14}$"));
    }

    // Test 4: Incorrectly formatted recipient number
    @Test
    public void testInvalidRecipientNumber() {
        String recipient = "0718693002";

        assertFalse(recipient.matches("^\\+[1-9]\\d{1,14}$"));
    }

    // Test 5: Message hash
    @Test
    public void testMessageHash() {
        String expectedHash = "00:0:HITONIGHT";

        assertEquals(expectedHash, "00:0:HITONIGHT");
    }

    // Test 6: Message ID generation
    @Test
    public void testMessageIDCreated() {
        String messageID = "MSG1234567890";

        assertNotNull(messageID);
        assertFalse(messageID.isEmpty());
        assertTrue(messageID.startsWith("MSG"));
    }

    // Test 7: Send Message
    @Test
    public void testSendMessage() {
        String action = "Send Message";
        String expected = "Message successfully sent.";

        assertEquals(expected, getMessageStatus(action));
    }

    // Test 8: Disregard Message
    @Test
    public void testDisregardMessage() {
        String action = "Disregard Message";
        String expected = "Press 0 to delete the message.";

        assertEquals(expected, getMessageStatus(action));
    }

    // Test 9: Store Message
    @Test
    public void testStoreMessage() {
        String action = "Store Message";
        String expected = "Message successfully stored.";

        assertEquals(expected, getMessageStatus(action));
    }

    // Method to determine the message status
    private String getMessageStatus(String action) {
        return switch (action) {
            case "Send Message" -> "Message successfully sent.";
            case "Disregard Message" -> "Press 0 to delete the message.";
            case "Store Message" -> "Message successfully stored.";
            default -> "Invalid action.";
        };
    }
}
    

